#include "basicGates.h"
#include <iostream>
#include <string>

Binary_t::Binary_t()
{
    value = 0;
    numBits = 0;
    binaryString = "";
}

Binary_t::Binary_t(std::string inputString)
{
    int i = 0;
    while (inputString[i] != 'b')
    {
        i++;
    }
    this->binaryString = inputString.substr(i + 1);
    this->numBits = binaryString.length();
    this->value = stoi(binaryString, nullptr, 2);
}

Binary_t::Binary_t(int value, int numBits)
{
    this->value = value;
    this->numBits = numBits;

    std::string binaryString = "";
    while (value > 0)
    {
        binaryString = (value % 2 == 0 ? "0" : "1") + binaryString;
        value /= 2;
    }
    this->binaryString = binaryString;
}

Binary_t BasicGates_t::myAnd(Binary_t a, Binary_t b, int gateDelay)
{
    int value = a.value & b.value;
    int numBits = a.numBits;
    Binary_t result(value, numBits);
    return result;
}

Binary_t BasicGates_t::myOr(Binary_t a, Binary_t b, int gateDelay)
{
    int value = a.value | b.value;
    int numBits = a.numBits;
    Binary_t result(value, numBits);
    return result;
}

Binary_t BasicGates_t::myNot(Binary_t a, int gateDelay)
{
    int value = ~a.value;
    int numBits = a.numBits;
    Binary_t result(value, numBits);
    return result;
}

Binary_t BasicGates_t::myNand(Binary_t a, Binary_t b, int gateDelay)
{
    int value = ~(a.value & b.value);
    int numBits = a.numBits;
    Binary_t result(value, numBits);
    return result;
}

Binary_t BasicGates_t::myNor(Binary_t a, Binary_t b, int gateDelay)
{
    int value = ~(a.value | b.value);
    int numBits = a.numBits;
    Binary_t result(value, numBits);
    return result;
}

Binary_t BasicGates_t::myXor(Binary_t a, Binary_t b, int gateDelay)
{
    int value = a.value ^ b.value;
    int numBits = a.numBits;
    Binary_t result(value, numBits);
    return result;
}

Binary_t BasicGates_t::myXnor(Binary_t a, Binary_t b, int gateDelay)
{
    int value = ~(a.value ^ b.value);
    int numBits = a.numBits;
    Binary_t result(value, numBits);
    return result;
}
