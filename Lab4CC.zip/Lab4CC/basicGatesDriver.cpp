#include "basicGates.h"
#include <iostream>
#include <string>

int main(int argc, char *argv[])
{
    if (argc != 3 && argc != 4)
    {
        std::cout << "Usage: ./basicGatesDriver gate a b" << std::endl;
        return 1;
    }
    std::string gate = argv[1];
    Binary_t a(argv[2]);
    Binary_t b(argv[3]);
    BasicGates_t basicGates;
    Binary_t result;
    switch (gate[0])
    {
    case 'and':
        result = basicGates.myAnd(a, b);
        break;
    case 'or':
        result = basicGates.myOr(a, b);
        break;
    case 'not':
        result = basicGates.myNot(a);
        break;
    case 'nand':
        result = basicGates.myNand(a, b);
        break;
    case 'nor':
        result = basicGates.myNor(a, b);
        break;
    case 'xor':
        result = basicGates.myXor(a, b);
        break;
    case 'xnor':
        result = basicGates.myXnor(a, b);
        break;
    default:
        std::cout << "Invalid gate" << std::endl;
        return 1;
    }
}
