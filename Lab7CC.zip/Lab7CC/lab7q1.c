int add(int lcl1, int lcl2)
{
    return lcl1 + lcl2;
}
int main()
{
    int var1 = 10;
    int var2 = 20;
    int var3 = 0;
    var3 = add(var1, var2);
    return 0;
}
