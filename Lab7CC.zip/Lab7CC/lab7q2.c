int var1 = 10;
int var2 = 20;
int add()
{
    return var1 + var2;
}
int main()
{
    int var3 = 0;
    var3 = add();
    return 0;
}
